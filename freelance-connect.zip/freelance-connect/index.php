<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Freelance Connect</title>
    <link rel="stylesheet" href="assets/css/style.css"> <!-- Adjust this based on file structure -->
</head>
<body>
    <header>
        <nav>
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="pages/browse_jobs.php">Browse Jobs</a></li>
                <li><a href="pages/post_job.php">Post a Job</a></li>
                <?php if (isset($_SESSION['user_id'])): ?>
                    <li><a href="pages/dashboard.php">Dashboard</a></li>
                    <li><a href="process/logout.php">Logout</a></li>
                <?php else: ?>
                    <li><a href="pages/login.php">Login</a></li>
                    <li><a href="pages/register.php">Register</a></li>
                <?php endif; ?>
            </ul>
        </nav>
    </header>
</body>
</html>


<!-- Hero Section -->
<div class="hero">
    <h1>Find Your Perfect Freelancer or Client</h1>
    <p>Join thousands of professionals on Freelance Connect to hire and get hired effortlessly.</p>
    <a href="pages/browse_jobs.php" class="btn">Find Jobs</a>
    <a href="pages/post_job.php" class="btn">Post a Job</a>
</div>

<!-- Key Features Section -->
<div class="features">
    <h2>Why Choose Freelance Connect?</h2>
    <div class="feature-box">
        <h3>AI Job Matching</h3>
        <p>Our smart system recommends the best freelancers and jobs based on your skills.</p>
    </div>
    <div class="feature-box">
        <h3>Secure Payments</h3>
        <p>Escrow-based payments ensure safe and smooth transactions for all users.</p>
    </div>
    <div class="feature-box">
        <h3>Seamless Communication</h3>
        <p>Integrated chat and messaging tools make collaboration easy.</p>
    </div>
</div>

<!-- Testimonials Section -->
<div class="testimonials">
    <h2>What Our Users Say</h2>
    <p class="testimonial">"Freelance Connect helped me find my dream projects and build my career!" - <strong>Sarah J.</strong></p>
    <p class="testimonial">"Posting a job was super easy, and I got amazing proposals within hours!" - <strong>Mark R.</strong></p>
</div>

<!-- Call to Action Section -->
<div class="cta">
    <h2>Ready to Get Started?</h2>
    <p>Join now and start your freelancing journey with ease.</p>
    <a href="pages/register.php" class="btn-light">Sign Up Now</a>
</div>

<?php include("includes/footer.php"); ?>
