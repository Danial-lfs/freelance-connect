<?php
session_start();
include("../includes/db_connect.php");

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: ../pages/login.php");
    exit();
}

// Process form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Validate CSRF Token
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        die("CSRF validation failed!");
    }

    // Sanitize input data to prevent XSS
    $title = htmlspecialchars(trim($_POST['title']));
    $description = htmlspecialchars(trim($_POST['description']));
    $budget = filter_var($_POST['budget'], FILTER_VALIDATE_FLOAT);
    $client_id = $_SESSION['user_id']; // Get client ID from session

    // Validate inputs
    if (empty($title) || empty($description) || !$budget || $budget < 1) {
        die("Error: All fields are required, and budget must be a valid positive number.");
    }

    // Prepare and execute the SQL statement securely
    $query = "INSERT INTO jobs (client_id, title, description, budget) VALUES (?, ?, ?, ?)";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("issd", $client_id, $title, $description, $budget);

    if ($stmt->execute()) {
        header("Location: ../pages/dashboard.php?success=job_posted"); // Redirect on success
        exit();
    } else {
        die("Error: " . $stmt->error);
    }

    $stmt->close();
}

// Close database connection
$conn->close();
?>
