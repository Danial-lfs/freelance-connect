<?php
session_start();
include("../includes/db_connect.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $job_id = $_POST['job_id'];
    $freelancer_id = $_SESSION['user_id'];
    $proposal = $_POST['proposal'];
    $bid_amount = $_POST['bid_amount'];

    // Check if the freelancer has already applied for the job
    $check_query = "SELECT * FROM applications WHERE job_id = $job_id AND freelancer_id = $freelancer_id";
    $check_result = $conn->query($check_query);

    if ($check_result->num_rows > 0) {
        echo "You have already applied for this job.";
        exit();
    }

    $query = "INSERT INTO applications (job_id, freelancer_id, proposal, bid_amount) 
              VALUES ('$job_id', '$freelancer_id', '$proposal', '$bid_amount')";

    if ($conn->query($query) === TRUE) {
        header("Location: ../pages/dashboard.php");
    } else {
        echo "Error: " . $conn->error;
    }
}

$conn->close();
?>
