<?php include("../includes/header.php"); ?>

<div class="container">
    <h2>Register</h2>
    <form action="../process/register_user.php" method="post">
        <input type="text" name="name" placeholder="Full Name" required>
        <input type="email" name="email" placeholder="Email" required>
        <input type="password" name="password" placeholder="Password" required>
        <button type="submit">Register</button>
    </form>
</div>

<?php include("../includes/footer.php"); ?>
