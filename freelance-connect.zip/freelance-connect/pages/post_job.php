<?php
session_start();

// Redirect to login if not logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

include("../includes/header.php");

// Generate CSRF token if not set
if (!isset($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
?>

<div class="container">
    <h2>Post a Job</h2>
    <form action="../process/post_job_process.php" method="post">
        <!-- Hidden CSRF Token -->
        <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">

        <label for="title">Job Title:</label>
        <input type="text" id="title" name="title" placeholder="Enter job title" required>

        <label for="description">Job Description:</label>
        <textarea id="description" name="description" placeholder="Enter job description" required></textarea>

        <label for="budget">Budget (USD):</label>
        <input type="number" id="budget" name="budget" placeholder="Enter budget amount" required min="1">

        <button type="submit">Post Job</button>
    </form>
</div>

<?php include("../includes/footer.php"); ?>
