<?php include("../includes/header.php"); ?>

<div class="container">
    <h2>Login</h2>
    <form action="../process/login_user.php" method="post">
        <input type="email" name="email" placeholder="Email" required>
        <input type="password" name="password" placeholder="Password" required>
        <button type="submit">Login</button>
    </form>
</div>

<?php include("../includes/footer.php"); ?>
