<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

include("../includes/header.php");
include("../includes/db_connect.php");

if (!isset($_GET['job_id'])) {
    echo "Invalid job ID.";
    exit();
}

$job_id = $_GET['job_id'];
$query = "SELECT applications.*, users.name AS freelancer_name 
          FROM applications 
          JOIN users ON applications.freelancer_id = users.id 
          WHERE applications.job_id = $job_id";

$result = $conn->query($query);
?>

<div class="container">
    <h2>Job Applications</h2>
    <?php while ($application = $result->fetch_assoc()): ?>
        <div class="application">
            <h3><?php echo $application['freelancer_name']; ?></h3>
            <p><strong>Proposal:</strong> <?php echo $application['proposal']; ?></p>
            <p><strong>Bid:</strong> $<?php echo $application['bid_amount']; ?></p>
        </div>
    <?php endwhile; ?>
</div>
<?php while ($application = $result->fetch_assoc()): ?>
    <div class="application">
        <h3><?php echo $application['freelancer_name']; ?></h3>
        <p><strong>Proposal:</strong> <?php echo $application['proposal']; ?></p>
        <p><strong>Bid:</strong> $<?php echo $application['bid_amount']; ?></p>
        <p><strong>Status:</strong> <?php echo ucfirst($application['status']); ?></p>
        <?php if ($application['status'] == 'pending'): ?>
            <a href="accept_freelancer.php?application_id=<?php echo $application['id']; ?>" class="btn">Accept Freelancer</a>
        <?php endif; ?>
    </div>
<?php endwhile; ?>

<?php include("../includes/footer.php"); ?>
